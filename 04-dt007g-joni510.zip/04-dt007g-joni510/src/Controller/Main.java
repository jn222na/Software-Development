package Controller;

import View.MainView;

public class Main {

	public static void main(String[] args) {
		MainView mv = new MainView();
		mv.drawWindow();
	}

}
