package View;

import java.awt.Graphics;


public abstract class Igraphs {
	

	abstract public void draw(Graphics g2, int d, double e, double f, double h);
	
}
